//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "SMTPhaseSegment.h"

SMTPhaseSegment::~SMTPhaseSegment() {
}

void SMTPhaseSegment::setState(double start, double end, string value) {
    if (end <= start) {
        std::cout << "Error: end time mush bigger than start time."
                << std::endl;
    }
    if (segIt == states.end() || segIt->time > start) {
        segIt = states.begin();
        preState = "x";
    }
    while (segIt != states.end() && segIt->time < start) {
        preState = segIt->value;
        segIt++;
    }
    string originState = preState;
    if (segIt != states.end() && segIt->time == start) {

        originState = segIt->value;
        if (preState != value) {

            segIt->value = value;

            preState = value;
            segIt++;
        } else {

            segIt = states.erase(segIt);
        }
    } else {

        if (preState != value) {
            State state;
            state.time = start;
            state.value = value;
            states.insert(segIt, state);

            originState = preState;

            preState = value;
        }
    }

    while (segIt != states.end() && segIt->time < end) {

        originState = segIt->value;
        segIt = states.erase(segIt);
    }

    if (segIt != states.end() && segIt->time == end) {

        if (preState == segIt->value) {

            segIt = states.erase(segIt);
        }
    } else {

        if (preState != originState) {
            State state;
            state.time = end;
            state.value = originState;
            states.insert(segIt, state);

            segIt--;

        }
    }
    updateHeadTailPeriod();
}

void SMTPhaseSegment::resetState(list<double> &segLens, list<string> &values,
        double start) {
    if (segLens.size() != values.size()) {
        std::cout << "unmatched segLens and values." << std::endl;
    }

    states.clear();
    segIt = states.begin();
    double begin = start;
    list<double>::iterator lenIt = segLens.begin();
    list<string>::iterator valIt = values.begin();

    while (lenIt != segLens.end() && valIt != values.end()) {
        double end = begin + *lenIt;
        setState(begin, end, *valIt);
        begin = end;
        lenIt++;
        valIt++;
    }
}

bool SMTPhaseSegment::moveCertainStateAHead(string value) {

    if (states.begin() == states.end()) {
        std::cout << "Error: Cannot move state in empty segment" << std::endl;
        return false;
    }
    list<State> t;

    list<State>::iterator endIt = states.end();
    --endIt;
    double end = endIt->time;

    if (endIt == states.begin()) {
        debugMoreThanOneNode();
        return false;
    }
    --endIt;
    string lastState = endIt->value;
    ++endIt;
    segIt = states.begin();

    double start = segIt->time;
    double period = end - start;
    while (segIt != states.end()) {

        if (segIt->value != value) {
            t.push_back(*segIt);
            segIt = states.erase(segIt);
        } else {

            start = segIt->time;

            for (list<State>::iterator it = t.begin(); it != t.end(); ++it) {
                it->time += period;
            }

            if (t.begin()->value == lastState) {
                t.pop_front();
            }

            double offset = period - end + start;
            states.insert(endIt, t.begin(), t.end());
            endIt->time += offset;
            break;
        }
    }
    if (segIt == states.end()) {
        states.swap(t);
        segIt = states.begin();
        preState = "x";
        std::cout << "Error: Cannot move the state not in the segment"
                << std::endl;
        return false;
    }

    segIt = states.begin();
    preState = "x";
    updateHeadTailPeriod();
    return true;
}

void SMTPhaseSegment::debugPrint() {
    std::cout << std::endl << "debug: print the segment content." << std::endl;
    std::cout << "head:" << head << " " << "tail:" << tail << " " << "period:"
            << period << std::endl;
    for (list<State>::iterator it = states.begin(); it != states.end();) {
        std::cout << it->time << ":" << it->value;
        ++it;
        if (it != states.end()) {
            std::cout << ", ";
        }
    }
    std::cout << std::endl;
}

double SMTPhaseSegment::getHead() {
    if (states.size() < 2) {
        debugMoreThanOneNode();
        return -1;
    }
    return states.front().time;
}

double SMTPhaseSegment::getTail() {
    if (states.size() < 2) {
        debugMoreThanOneNode();
        return -1;
    }
    return states.back().time;
}

double SMTPhaseSegment::getPeriod() {
    if (states.size() < 2) {
        debugMoreThanOneNode();
        return -1;
    }
    return states.back().time - states.front().time;
}

void SMTPhaseSegment::updateHeadTailPeriod() {
    head = getHead();
    tail = getTail();
    period = getPeriod();
}

void SMTPhaseSegment::debugMoreThanOneNode() {
    std::cout << "Error: Segment must have more than one node" << std::endl;
}
