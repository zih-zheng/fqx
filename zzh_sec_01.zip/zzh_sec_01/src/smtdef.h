#pragma once

#include <omnetpp.h>

#if defined(SMT_EXPORT)
#  define SMT_API OPP_DLLEXPORT
#elif defined(SMT_IMPORT)
#  define SMT_API OPP_DLLIMPORT
#else
#  define SMT_API
#endif



