//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#pragma once

#include "smtdef.h"
#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"

using namespace veins;

class SMT_API ZZHAuthRSUApp: public DemoBaseApplLayer {
public:
    void initialize(int stage) override;
    void finish() override;
    class StatisticsInfo {
    public:
        int receivedAuthMsg = 0;
    };

protected:
    double calcDelay;
    double calcDelayRnd;
    double hopDelay;
    double hopDelayRnd;
    int hopNum;
    StatisticsInfo statistics;
    void populateWSM(BaseFrame1609_4 *wsm, LAddress::L2Type rcvId =
            LAddress::L2BROADCAST(), int serial = 0);
    void onWSM(BaseFrame1609_4 *wsm) override;

};

