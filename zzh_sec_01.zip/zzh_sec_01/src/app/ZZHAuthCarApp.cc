//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
//

#include "veins/modules/application/traci/TraCIDemo11pMessage_m.h"
#include "StatisticsRecordTools.h"
#include "ZZHAuthCarApp.h"
#include "ZZHAuthConst.h"

Define_Module(ZZHAuthCarApp);

void ZZHAuthCarApp::initialize(int stage) {
    DemoBaseApplLayer::initialize(stage);
    if (stage == 0) {
        hasAuthenticated = false;
        inAuthentication = false;
        calcDelay = par("calcDelay").doubleValue();
        calcDelayRnd = par("calcDelayRnd").doubleValue();
        hopDelay = par("hopDelay").doubleValue();
        hopDelayRnd = par("hopDelayRnd").doubleValue();
        hopNum = par("hopNum").intValue();
        retryInterval = par("retryInterval").doubleValue();
        tryAuthMsg = new cMessage("Try Auth Again");
    }
}


void ZZHAuthCarApp::onBSM(DemoSafetyMessage *bsm) {
    if (inAuthentication) {
        return;
    }
    if (bsm->getPsid() != ZZHAuthConst::AuthServerId) {
        return;
    }
    findHost()->getDisplayString().setTagArg("i", 1, "red");
    inAuthentication = true;
    authStartTime = simTime().dbl();
    sendAuthMsg();
}


void ZZHAuthCarApp::onWSM(BaseFrame1609_4 *wsm) {
    if (TraCIDemo11pMessage *amsg = dynamic_cast<TraCIDemo11pMessage*>(wsm)) {
        if (amsg->getSenderAddress() == myId) {
            findHost()->getDisplayString().setTagArg("i", 1, "green");
            hasAuthenticated = true;
            statistics.authDelay = simTime().dbl() - authStartTime;
            cancelAndDelete(tryAuthMsg);
        }
    }
}


void ZZHAuthCarApp::handleSelfMsg(cMessage *msg) {
    if (msg == tryAuthMsg) {
        sendAuthMsg();
    }
}

void ZZHAuthCarApp::finish() {
    auto srt = Fanjing::StatisticsRecordTools::request();
    srt->changeName("CarSendNum", "") << mobility->getExternalId()
            << statistics.sendNum << srt->endl;
    srt->changeName("CarAuthDelay", "") << mobility->getExternalId()
            << statistics.authDelay << srt->endl;
    srt->changeName("CarInAuthentication", "") << mobility->getExternalId()
            << (inAuthentication ? 1 : 0) << srt->endl;
    srt->changeName("CarHasAuthenticated", "") << mobility->getExternalId()
            << (hasAuthenticated ? 1 : 0) << srt->endl;

}

void ZZHAuthCarApp::handlePositionUpdate(cObject *obj) {
}

void ZZHAuthCarApp::sendAuthMsg() {
    ++statistics.sendNum;
    TraCIDemo11pMessage *wsm = new TraCIDemo11pMessage();
    populateWSM(wsm);
    wsm->setSenderAddress(myId);
    double calcTime = calcDelay + uniform(0, calcDelayRnd);
    double hopTime = 0;
    for (int hopIdx = 0; hopIdx < hopNum; ++hopIdx) {
        hopTime += hopDelay + uniform(0, hopDelayRnd);
    }
    sendDelayedDown(wsm, calcTime + hopTime);
    scheduleAt(simTime() + retryInterval, tryAuthMsg);
}
