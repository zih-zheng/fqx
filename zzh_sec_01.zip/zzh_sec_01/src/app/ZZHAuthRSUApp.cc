//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "veins/modules/application/traci/TraCIDemo11pMessage_m.h"
#include "StatisticsRecordTools.h"
#include "ZZHAuthConst.h"
#include "ZZHAuthRSUApp.h"

Define_Module(ZZHAuthRSUApp);


void ZZHAuthRSUApp::initialize(int stage) {
   DemoBaseApplLayer::initialize(stage);
   if (stage == 0) {
       calcDelay = par("calcDelay").doubleValue();
       calcDelayRnd = par("calcDelayRnd").doubleValue();
       hopDelay = par("hopDelay").doubleValue();
       hopDelayRnd = par("hopDelayRnd").doubleValue();
       hopNum = par("hopNum").intValue();
   }
}


void ZZHAuthRSUApp::populateWSM(BaseFrame1609_4 *wsm, LAddress::L2Type rcvId,
        int serial) {
    wsm->setRecipientAddress(rcvId);
    wsm->setBitLength(headerLength);
    if (DemoSafetyMessage* bsm = dynamic_cast<DemoSafetyMessage*>(wsm)) {

        bsm->setSenderPos(curPosition);
        bsm->setSenderSpeed(curSpeed);
        bsm->setPsid(ZZHAuthConst::AuthServerId);
        bsm->setChannelNumber(static_cast<int>(Channel::cch));
        bsm->addBitLength(beaconLengthBits);
        wsm->setUserPriority(beaconUserPriority);
    }else{
        DemoBaseApplLayer::populateWSM(wsm, rcvId, serial);
    }

}

void ZZHAuthRSUApp::finish() {
    auto srt = Fanjing::StatisticsRecordTools::request();
    srt->changeName("RsuRreceivedAuthMsg", "") << "RSU"
            << statistics.receivedAuthMsg << srt->endl;
}

void ZZHAuthRSUApp::onWSM(BaseFrame1609_4 *wsm) {
    if (TraCIDemo11pMessage *amsg = dynamic_cast<TraCIDemo11pMessage*>(wsm)) {
        ++statistics.receivedAuthMsg;
        TraCIDemo11pMessage* rsm = new TraCIDemo11pMessage();
        populateWSM(rsm);
        rsm->setSenderAddress(amsg->getSenderAddress());
        double calcTime = calcDelay + uniform(0, calcDelayRnd);
        double hopTime = 0;
        for (int hopIdx = 0; hopIdx < hopNum; ++hopIdx) {
            hopTime += hopDelay+ uniform(0,hopDelayRnd);
        }
        sendDelayedDown(rsm, calcTime + hopTime);
    }
    DemoBaseApplLayer::onWSM(wsm);
}

