
#pragma once


namespace ZZHAuthConst {

const int AuthServerId = 71;

}
