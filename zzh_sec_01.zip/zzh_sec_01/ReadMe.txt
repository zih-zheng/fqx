Unlike Linux shared libraries which can be built from any C/C++ code, Windows has special rules for code that goes into DLLs. When a DLL is built, all symbols (functions, global variables, etc.) that you want to expose as C/C++ API to users of your DLL need to be marked with the __declspec(dllexport) qualifier. Likewise, when you refer a symbol (function, variable, etc) that comes from a DLL, the C/C++ declaration of that symbol needs to be annotated with __declspec(dllimport).
 
In OMNeT++, we introduce a convention to automate the process as far as possible, using macros. To build a DLL, you need to pick a short name for it, say FOO, and add the following code to a header file (say foodefs.h):
 
 
#include <omnetpp.h>

#if defined(FOO_EXPORT)
#  define FOO_API OPP_DLLEXPORT
#elif defined(FOO_IMPORT)
#  define FOO_API OPP_DLLIMPORT
#else
#  define FOO_API
#endif
 
 
Then you need to include foodefs.h into all your header files, and annotate public symbols in them with FOO_API. Also, insert the following in your .msg files:
 
 
cplusplus {{
  #include "foodefs.h"
}}
 
 
When building the DLL, OMNeT++-generated makefiles will ensure that FOO_EXPORT is defined, and so FOO_API becomes __declspec(dllexport). Likewise, when you use the DLL from external code, the makefile will define FOO_IMPORT, causing FOO_API to become __declspec(dllimport). In all other cases, for example when compiling on Linux, FOO_API will be empty.
 
 
Here's how to annotate classes, functions and global variables:
 
 
class FOO_API SomeClass {
  ...
};

int FOO_API someFunction(double a, int b);

extern int FOO_API globalVariable; //note: global variables are discouraged
 
If you have 3rd-party DLLs which use a different convention to handle dllexport/dllimport, you need to manually specify the corresponding macros on the "Paths and symbols" page of the project properties dialog.
 
