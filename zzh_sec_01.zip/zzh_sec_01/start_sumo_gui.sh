#!/usr/bin/bash

/d/Work/workspace/omnetpp-wangjing/veins/bin/veins_launchd -vv -c /d/Work/Tools/sumo/sumo-1.8.0/bin/sumo-gui.exe
